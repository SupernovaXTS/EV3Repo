# Pybricks for EV3

## Building

See the [docker](./docker) folder for build instructions.
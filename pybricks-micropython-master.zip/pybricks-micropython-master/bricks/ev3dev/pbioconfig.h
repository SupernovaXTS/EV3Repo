// SPDX-License-Identifier: MIT
// Copyright (c) 2019-2020 The Pybricks Authors

#define PBIO_CONFIG_EV3_INPUT_DEVICE        (1)
#define PBIO_CONFIG_DCMOTOR                 (1)
#define PBIO_CONFIG_LIGHT                   (1)
#define PBIO_CONFIG_SERIAL                  (1)
#define PBIO_CONFIG_TACHO                   (1)

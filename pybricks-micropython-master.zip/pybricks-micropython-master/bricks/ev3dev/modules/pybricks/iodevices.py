# SPDX-License-Identifier: MIT
# Copyright (c) 2018-2020 The Pybricks Authors

"""Classes for generic I/O devices."""

from _pybricks.iodevices import *

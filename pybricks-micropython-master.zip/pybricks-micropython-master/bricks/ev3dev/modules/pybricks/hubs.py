# SPDX-License-Identifier: MIT
# Copyright (c) 2018-2020 The Pybricks Authors

from _pybricks.hubs import EV3Brick

By default, the large submodules found here are not cloned, because we do not
actively support or develop this port.

To download them, stay in this folder (`bricks/ev3rt`) and do this:

    git submodule update --checkout --init --recursive

The Makefile should do this for you automatically.

// qstrs specific to this port
// *FORMAT-OFF*
Q(Li-ion)
Q(stop button pressed)

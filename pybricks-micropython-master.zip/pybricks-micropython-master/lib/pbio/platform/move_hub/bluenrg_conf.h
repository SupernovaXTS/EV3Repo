// SPDX-License-Identifier: MIT
// Copyright (c) 2018-2020 The Pybricks Authors

#ifndef _BLUENRG_CONF_H_
#define _BLUENRG_CONF_H_


#define HCI_MAX_PAYLOAD_SIZE        127

#endif /* _BLUENRG_CONF_H_ */


// SPDX-License-Identifier: MIT
// Copyright (c) 2020-2021 The Pybricks Authors

#define PBSYS_CONFIG_BLUETOOTH                      (1)
#define PBSYS_CONFIG_HUB_LIGHT_MATRIX               (1)
#define PBSYS_CONFIG_STATUS_LIGHT                   (1)

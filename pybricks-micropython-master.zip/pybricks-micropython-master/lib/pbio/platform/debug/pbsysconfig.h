// SPDX-License-Identifier: MIT
// Copyright (c) 2020-2021 The Pybricks Authors

#define PBSYS_CONFIG_BLUETOOTH                      (0)
#define PBSYS_CONFIG_HUB_LIGHT_MATRIX               (0)
#define PBSYS_CONFIG_STATUS_LIGHT                   (1)

.. Nothing to see here, this project uses Doxygen. This file is just a
   placeholder so we can use sphinx-doc to build the Doxygen docs for
   readthedocs.org compatibility.

This directory contains the source code of the main library.

All code here should be platform agnostic.

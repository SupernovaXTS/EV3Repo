// SPDX-License-Identifier: MIT
// Copyright (c) 2019-2020 The Pybricks Authors

#ifndef _INTERNAL_PBDRV_ADC_STM32_HAL_H_
#define _INTERNAL_PBDRV_ADC_STM32_HAL_H_

void pbdrv_adc_stm32_hal_handle_irq(void);

#endif // _INTERNAL_PBDRV_ADC_STM32_HAL_H_

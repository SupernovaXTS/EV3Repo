The software in this folder was obtained from the X-CUBE-BLE1 Bluetooth Low
Energy software expansion for STM32Cube and is licensed under the license
contained in LICENSE.txt in this directory. The software has been modified
from the original source.

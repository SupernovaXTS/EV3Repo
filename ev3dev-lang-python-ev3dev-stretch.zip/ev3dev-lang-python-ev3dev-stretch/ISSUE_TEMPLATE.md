<!--
    Before we can help you, we need some information about what you are trying to do and what software you are using.
    Please fill out the information below.
-->

- **ev3dev version:** PASTE THE OUTPUT OF `uname -r` HERE
- **ev3dev-lang-python version:** INSERT ALL VERSIONS GIVEN BY `dpkg-query -l {python3,micropython}-ev3dev*` HERE

<!-- Now tell us about what you were trying to do, and include any error messages you received. Be specific and include any involved code, please! Make sure to include your import statements as well. -->


Lego Port
=========

The `LegoPort` class is only needed when manually reconfiguring input/output
ports. This is necessary on the BrickPi but not other platforms, such as the
EV3. Most users can ignore this page.

.. autoclass:: ev3dev2.port.LegoPort
    :members:
Sound
=====

.. autoclass:: ev3dev2.sound.Sound
    :members: